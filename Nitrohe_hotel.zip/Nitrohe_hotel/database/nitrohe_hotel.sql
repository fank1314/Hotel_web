/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50617
Source Host           : localhost:3306
Source Database       : hb5272230

Target Server Type    : MYSQL
Target Server Version : 50617
File Encoding         : 65001

Date: 2018-12-08 09:59:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '管理员号',
  `name` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '管理员姓名',
  `passwd` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='管理员表';

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'admin', 'zls');
INSERT INTO `admin` VALUES ('3', 'aaa', 'abc');
INSERT INTO `admin` VALUES ('4', 'xiaoming', '123');

-- ----------------------------
-- Table structure for message
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `ms_id` int(4) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(30) NOT NULL COMMENT '主题',
  `name` varchar(10) NOT NULL COMMENT '名字',
  `mailbox` varchar(50) NOT NULL COMMENT '邮箱',
  `phone` int(20) NOT NULL COMMENT '手机',
  `content` varchar(240) NOT NULL COMMENT '留言内容',
  PRIMARY KEY (`ms_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('12', '搜索', 'LeeSlow', '1251662462@qq.com', '2147483647', 'ss');
INSERT INTO `message` VALUES ('13', '啊啊', 'LeeSlow', '1161942111@qq.com', '2147483647', 'ss');

-- ----------------------------
-- Table structure for news
-- ----------------------------
DROP TABLE IF EXISTS `news`;
CREATE TABLE `news` (
  `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '序号',
  `title` varchar(30) NOT NULL COMMENT '图片标题',
  `spic` varchar(100) NOT NULL COMMENT '小图片',
  `bpic` varchar(100) NOT NULL COMMENT '大图片',
  `describes` varchar(240) NOT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of news
-- ----------------------------
INSERT INTO `news` VALUES ('1', '纽约公寓里的独立房间', '20181207043321.jpg', '201812070433212.jpg', '有独立房间，与房东或房客分享合用空间');
INSERT INTO `news` VALUES ('3', '在舊金山，找到了一個家', '20181207043624.jpg', '201812070436242.jpg', '說到旅行, 一個對的人，一本適合的書，一顆自由的心，這樣就足以構成');
INSERT INTO `news` VALUES ('4', '舌尖上的美食', '20180425035522.jpg', '201804250355222.jpg', '美食不可辜负');
INSERT INTO `news` VALUES ('5', '成都民宿270度无敌观景日式禅意房', '20181207043855.jpg', '201812070438552.jpg', '朗御32楼,看起来不太网红风的日式禅意房，晚上可以看夜景');
INSERT INTO `news` VALUES ('6', '干净整洁的卫生间', '20180425035622.jpg', '201804250356222.jpg', '美好体验无烦恼');
INSERT INTO `news` VALUES ('8', '便利的停车场', '20180425035714.jpg', '201804250357142.jpg', '给你的爱车一个更好的环境');
INSERT INTO `news` VALUES ('10', '巴厘岛的丛林屋（Jungle Room）', '20181207044208.jpg', '201812070442082.jpg', '在Jungle Room中度过整个慵懒的上午');
INSERT INTO `news` VALUES ('11', '台湾近動物園及貓空纜車', '20181207043046.jpg', '201812070430462.jpg', '擁有超棒夜景可以看到台北101的渡假小屋臥室為一張加大雙人床套房');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `orderid` int(15) NOT NULL COMMENT '订单流水号',
  `roomid` varchar(4) COLLATE utf8_bin NOT NULL COMMENT '房间编号',
  `cardid` varchar(25) COLLATE utf8_bin NOT NULL COMMENT '客户身份证',
  `entertime` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '入住时间',
  `days` int(3) NOT NULL DEFAULT '1' COMMENT '住宿天数',
  `typeid` int(4) NOT NULL COMMENT '房间类型',
  `linkman` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '客户姓名',
  `phone` varchar(11) COLLATE utf8_bin NOT NULL COMMENT '联系电话',
  `ostatus` char(1) COLLATE utf8_bin NOT NULL DEFAULT '否' COMMENT '是否网上预订',
  `oremarks` char(1) COLLATE utf8_bin NOT NULL DEFAULT '否' COMMENT '订单是否完成',
  `monetary` decimal(8,2) NOT NULL COMMENT '消费金额',
  `messages` varchar(255) COLLATE utf8_bin DEFAULT '无备注信息' COMMENT '订单备注信息',
  PRIMARY KEY (`orderid`),
  KEY `FK_ORDER` (`typeid`),
  CONSTRAINT `FK_ORDER` FOREIGN KEY (`typeid`) REFERENCES `roomtype` (`typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='订单入住表';

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for record
-- ----------------------------
DROP TABLE IF EXISTS `record`;
CREATE TABLE `record` (
  `orderid` int(15) NOT NULL COMMENT '订单流水号',
  `roomid` varchar(4) COLLATE utf8_bin NOT NULL COMMENT '房间编号',
  `cardid` varchar(25) COLLATE utf8_bin NOT NULL COMMENT '客户身份证',
  `entertime` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '入住时间',
  `days` int(3) NOT NULL DEFAULT '1' COMMENT '住宿天数',
  `typeid` int(4) NOT NULL COMMENT '房间类型',
  `linkman` varchar(10) COLLATE utf8_bin NOT NULL COMMENT '客户姓名',
  `phone` varchar(11) COLLATE utf8_bin NOT NULL COMMENT '联系电话',
  `ostatus` char(1) COLLATE utf8_bin NOT NULL DEFAULT '否' COMMENT '是否网上预订',
  `oremarks` char(1) COLLATE utf8_bin NOT NULL DEFAULT '否' COMMENT '订单是否完成',
  `monetary` decimal(8,2) NOT NULL COMMENT '消费金额',
  `messages` varchar(255) COLLATE utf8_bin DEFAULT '无备注信息' COMMENT '订单备注信息',
  PRIMARY KEY (`orderid`),
  KEY `FK_ORDER` (`typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='订单入住历史表';

-- ----------------------------
-- Records of record
-- ----------------------------
INSERT INTO `record` VALUES ('24345', '101', '350902199703089367', '2018-12-09', '8', '1000', '小红', '13950107031', '是', '是', '1504.00', '小红');
INSERT INTO `record` VALUES ('31214', '102', '430281199412150313', '2018-12-01', '2', '1001', '烂人', '18473481922', '否', '是', '576.00', '烂人');
INSERT INTO `record` VALUES ('45018', '105', '350981199803085449', '2018-12-13', '3', '1000', '暖风撩人', '18859237381', '是', '是', '564.00', '暖风撩人');
INSERT INTO `record` VALUES ('45130', '106', '35098119980308004X', '2018-12-25', '7', '1001', '活著', '18859288234', '是', '是', '2016.00', '沒心沒肺的活著');

-- ----------------------------
-- Table structure for room
-- ----------------------------
DROP TABLE IF EXISTS `room`;
CREATE TABLE `room` (
  `roomid` varchar(4) COLLATE utf8_bin NOT NULL COMMENT '房间编号',
  `typeid` int(4) NOT NULL COMMENT '类型标识',
  `status` char(1) COLLATE utf8_bin NOT NULL COMMENT '是否入住',
  `remarks` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT '房间描述',
  `pic` varchar(100) COLLATE utf8_bin NOT NULL COMMENT '房间图片',
  PRIMARY KEY (`roomid`),
  UNIQUE KEY `roomid` (`roomid`),
  KEY `FK_ID` (`typeid`),
  CONSTRAINT `FK_ID` FOREIGN KEY (`typeid`) REFERENCES `roomtype` (`typeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of room
-- ----------------------------
INSERT INTO `room` VALUES ('101', '1000', '否', '一张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'd1.jpg');
INSERT INTO `room` VALUES ('102', '1001', '是', '两张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'a1.jpg');
INSERT INTO `room` VALUES ('103', '1005', '是', '商务两张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'a3.jpg');
INSERT INTO `room` VALUES ('104', '1003', '是', '商务一张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'd3.jpg');
INSERT INTO `room` VALUES ('105', '1000', '否', '一张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'd2.jpg');
INSERT INTO `room` VALUES ('106', '1001', '否', '两张床，房间配套设施——牙刷、牙膏、肥皂、梳子、一次性拖鞋等一套，风筒、空调、热水...', 'a2.jpg');
INSERT INTO `room` VALUES ('109', '1003', '否', '商务房间标配：一张床，内部设施非常齐全...', '20181208022846.jpg');
INSERT INTO `room` VALUES ('110', '1005', '否', '商务两张床，房间标配：内部设施非常齐全...', '20181208022506.jpg');

-- ----------------------------
-- Table structure for roomtype
-- ----------------------------
DROP TABLE IF EXISTS `roomtype`;
CREATE TABLE `roomtype` (
  `typeid` int(4) NOT NULL AUTO_INCREMENT COMMENT '类型标识',
  `typename` varchar(20) COLLATE utf8_bin NOT NULL COMMENT '类型名称',
  `area` varchar(2) COLLATE utf8_bin NOT NULL COMMENT '房间面积',
  `hasNet` char(1) COLLATE utf8_bin NOT NULL DEFAULT '有' COMMENT '网络',
  `hasTV` char(1) COLLATE utf8_bin NOT NULL DEFAULT '有' COMMENT '有线电视',
  `price` decimal(8,2) NOT NULL COMMENT '价格',
  `totalnum` int(4) NOT NULL COMMENT '房间数量',
  `leftnum` int(4) NOT NULL COMMENT '剩余数量',
  PRIMARY KEY (`typeid`)
) ENGINE=InnoDB AUTO_INCREMENT=1006 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='房间类型表';

-- ----------------------------
-- Records of roomtype
-- ----------------------------
INSERT INTO `roomtype` VALUES ('1000', '标准间【单人】', '40', '有', '有', '188.00', '2', '2');
INSERT INTO `roomtype` VALUES ('1001', '标准间【双人】', '70', '有', '有', '288.00', '2', '1');
INSERT INTO `roomtype` VALUES ('1003', '商务间【单人】', '50', '有', '有', '270.00', '2', '2');
INSERT INTO `roomtype` VALUES ('1005', '商务间【双人】', '80', '有', '有', '320.00', '2', '1');
